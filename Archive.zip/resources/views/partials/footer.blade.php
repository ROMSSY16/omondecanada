<footer class="footer py-4 p-4  ">

    <div class="row align-items-center justify-content-lg-between">
        <div class="copyright text-center text-sm text-muted text-lg-start">
            ©Omonde CANADA,
            made with <i class="fa fa-heart"></i> by
            <a href="https://omondecanada.com" class="font-weight-bold" target="_blank">TeamDEV OMONDE CANADA</a>
        </div>
    </div>
</footer>
